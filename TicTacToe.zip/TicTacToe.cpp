#include <iostream>
#include <conio.h>
#include <limits>
#include <cstring>
#include <fstream>
#include <cstdlib>
using namespace std;
const int ESC = 27;
class Player_Name
{
private:
    char name_1[25]; // Player-1 Name.
    char name_2[25]; // Player-2 Name.
    char ST;         // A temp variable used to know either the game will be a single match or tournament.
    int loop;        // For tournament

public:
    Player_Name() : name_1({}), name_2({}), ST('\0'), loop(0)
    {
    }
    void Game_start()
    {
        // cout << "Game_start() called\n";

        string str1; // Temp variable.
        string str2; // Temp variable.
        int z = 0;   // Temp variable.--For wrong name-1(only runs for name 1)
        int y = 0;   // Temp variable.--For wrong name-2(onlu runs for name 2)
        while (true)
        {
            if (z == 0)
            {
                z = 1;
                cout << "Enter Player-1 name: ";
                getline(cin, str1);
                size_t str1_Length = str1.size();
                str1_Length = (str1_Length < 25 ? str1_Length : 24);
                name_1[str1_Length] = '\0';
                str1.copy(name_1, str1_Length);

                if (!isValidName(name_1))
                {
                    z = 0;
                    cout << "Invalid Player-1 name. Enter again." << endl;
                    continue;
                }
            }
            if (y == 0)
            {
                y = 1;
                cout << "Enter Player-2 name: ";
                getline(cin, str2);
                size_t str2_Length = str2.size();
                str2_Length = (str2_Length < 25 ? str2_Length : 24);
                name_2[str2_Length] = '\0';
                str2.copy(name_2, str2_Length);
                if (!isValidName(name_2))
                {
                    y = 0;
                    cout << "Invalid Player-2 name. Enter again." << endl;
                    continue;
                }
            }
            break;
        }

        // cout << get_player_1();
        // cout << get_player_2();
        // Function call for Single/Tournament.--------------------------------------->
        S_T();
    }
    void S_T()
    {
        int flag = 0;
        while (true)
        {
            cout << "\n\tIf you want to play a single match Press 'S' And for tournament press 'T': ";
            ST = getche();              // Input Choice.
            if (ST == 'S' || ST == 's') // For Single Match.
            {
                loop = 1;
                break;
            }
            else if (ST == 'T' || ST == 't') // For Tournament.
            {
                while (true)
                {
                    cout << "\n\tEnter how many times you want to play ->";
                    cin >> loop;
                    if (cin.fail() || loop < 1)
                    {
                        cin.clear();
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        cout << "Invalid box number entered. Please enter a valid choice.\n";
                        continue;
                    }
                    if (loop % 2 != 0) // Check for odd numbers for game.
                    {
                        flag = 1;
                        break;
                    }
                    else // user Input even number.
                    {
                        system("cls");
                        cout << "\n  Please enter odd numbers to play tournament \n";
                    }
                }
                if (flag == 1)
                {
                    break;
                }
            }
            else
            {
                system("cls");
                cout << "\n  Invalid Choice Enter Again: ";
            }
        }
    }
    string get_player_1()
    {
        return name_1;
    }
    string get_player_2()
    {
        return name_2;
    }
    int get_loop()
    {
        // cout << "get_loop() Called \n";
        return loop;
    }
    char get_st()
    {
        return ST;
    }
    bool isValidName(const char *name) // Input validation for name.
    {
        for (int i = 0; i < strlen(name); i++)
        {
            char c = name[i];
            if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == ' '))
            {
                return false;
            }
        }
        return true;
    }
    void writeToFile(ofstream &file_)
    {
        file_.write(reinterpret_cast<const char *>(this), sizeof(*this));
    }
    void F_H1() // Sequential Writing Names And Match.
    {
        int G = 0;
        ofstream write;
        write.open("data.txt", ios::out);

        write << "\n\nGame " << ++G << endl;
        write << "player-1: " << name_1 << endl;
        write << "player-2: " << name_2 << endl;

        if (ST == 'S' || ST == 's')
        {
            write << "Single Match " << endl;
        }
        if (ST == 'T' || ST == 't')
        {
            write << "Tournament " << endl;
        }
        write << "\n\t\t\t\tTic Tac Toe Game\n";
        write << "\t\t\t\t     START\n";
        write << "\t\t\t\t   Player 1[X]\n";
        write << "\t\t\t\t   Player 2[O]\n";
        write.close();
    }

    ~Player_Name() {};
};
//<------------------------------------------------------------------------------------------------------------------------------------->

//<------------------------------------------------------------------------------------------------------------------------------------->
class Game : public Player_Name
{
private:
    char N[3][3] = {{'1', '2', '3'}, {'4', '5', '6'}, {'7', '8', '9'}}; // Box Values.
    int row;                                                            // Index Value.
    int column;                                                         // Index Value.
    char turn;                                                          // X/O
    int choice;                                                         // Box Number From User
    int draw;                                                           // To check condition for draw matches.
    int P1;                                                             // Player-1 wins count.
    int P2;                                                             // Player-2 wins count.
    int D;                                                              // To count draw matches.
    int loop_control = 0;

public:
    // Default Constructor.------------------------------------------------------------>
    Game() : row(NULL), column(NULL), turn('X'), choice(NULL), draw(1), P1(0), P2(0), D(0)
    {
    }
    // Structure of the Game.---------------------------------------------------------->
    void Start()
    {
        // cout << "Start() called\n";
        Structure();
        Player_Turn();
    }
    void Structure()
    {
        cout << "\n\t\t\t\tTic Tac Toe Game\n";
        cout << "\t\t\t\t     START\n";
        cout << "\t\t\t\t   Player 1[X]\n";
        cout << "\t\t\t\t   Player 2[O]\n";
        cout << "\n\t\t"
             << "\t\t|\t\t|\n";
        cout << "\t\t"
             << "\t\t|\t\t|\n";
        cout << "\t\t"
             << "\t" << N[0][0] << "\t|\t" << N[0][1] << "\t|\t" << N[0][2] << "\t\n";
        cout << "\t\t"
             << "\t\t|\t\t|\n";
        cout << "\t\t"
             << "----------------|---------------|------------\n";
        cout << "\t\t"
             << "\t\t|\t\t|\n";
        cout << "\t\t"
             << "\t\t|\t\t|\n";
        cout << "\t\t"
             << "\t" << N[1][0] << "\t|\t" << N[1][1] << "\t|\t" << N[1][2] << "\t\n";
        cout << "\t\t"
             << "\t\t|\t\t|\n";
        cout << "\t\t"
             << "\t\t|\t\t|\n";
        cout << "\t\t"
             << "----------------|---------------|-------------\n";
        cout << "\t\t"
             << "\t\t|\t\t|\n";
        cout << "\t\t"
             << "\t\t|\t\t|\n";
        cout << "\t\t"
             << "\t" << N[2][0] << "\t|\t" << N[2][1] << "\t|\t" << N[2][2] << "\t\n";
        cout << "\t\t"
             << "\t\t|\t\t|\n";
        cout << "\t\t"
             << "\t\t|\t\t|\n";
    }
    // Enter 'X' || 'O' in the Array index by checking conditions.------------------------------>
    void Player_Turn()
    {
        cout << "If you wish to exit press esc button any time between match." << endl;

        while (true)
        {
            if (turn == 'X') // Player_1's Turn.
            {
                cout << "\n\t\tPlayer_1->";
                cout << Player_Name::get_player_1();
                cout << "'s Turn: ";
            }
            if (turn == 'O') // Player_2's Turn.
            {
                cout << "\n\t\tPlayer_2->";
                cout << Player_Name::get_player_2() << "'s Turn: ";
            }
            char ch;
            ch = getche();
            if (ch == ESC)
            {
                cout << "\n\nYou exit the game.";
                ofstream write;
                write.open("data.txt", ios::app);
                write << "\n\nYou exit the game.";
                write.close();
                exit(0);
            }
            choice = int(ch) - 48;
            // cin >> choice;
            // cin.fail() checks if the input operation failed, indicating that the player did not enter a valid integer.
            if (cin.fail() || choice < 1 || choice > 9)
            {
                // cin.ignore() clears the input buffer, discarding any remaining characters up to and including the newline character ('\n').
                cin.clear(); // cin.clear(): clears the error state of the input stream.

                // cin.ignore(numeric_limits<streamsize>::max(), '\n'); is used to discard all characters from the input buffer
                // until and including the newline character ('\n'). This ensures that any invalid input or newline characters
                // entered by the user are cleared from the buffer before proceeding.
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << "Invalid box number entered. Please enter a valid choice.\n";
            }
            else
            {
                break;
            }
        }
        switch (choice) // compare choice.
        {
        case 1:
            row = 0;
            column = 0;
            break;
        case 2:
            row = 0;
            column = 1;
            break;
        case 3:
            row = 0;
            column = 2;
            break;
        case 4:
            row = 1;
            column = 0;
            break;
        case 5:
            row = 1;
            column = 1;
            break;
        case 6:
            row = 1;
            column = 2;
            break;
        case 7:
            row = 2;
            column = 0;
            break;
        case 8:
            row = 2;
            column = 1;
            break;
        case 9:
            row = 2;
            column = 2;
            break;
        default:
            // Nothing.
            break;
        }
        if (turn == 'X' && N[row][column] != 'X' && N[row][column] != 'O') // Put 'X' in the selected BOX.
        {
            N[row][column] = 'X';
            turn = 'O';
        }
        else if (turn == 'O' && N[row][column] != 'X' && N[row][column] != 'O') // Put 'O' in the selected BOX.
        {
            N[row][column] = 'O';
            turn = 'X';
        }
        else // If already ther is 'X' || 'O'.
        {
            cout << "\n\tBox already filled ";
            Player_Turn();
        }
    }
    bool game_() // check win
    {
        // cout << "game_() called \n";

        // vertically & horizontlly
        for (int i = 0; i < 3; i++)
        {
            if (N[i][0] == N[i][1] && N[i][0] == N[i][2] || N[0][i] == N[1][i] && N[0][i] == N[2][i])
            {
                draw = 0;
                return 0;
            }
        }
        // check diagonally
        if (N[0][0] == N[1][1] && N[0][0] == N[2][2] || N[0][2] == N[1][1] && N[1][1] == N[2][0])
        {
            draw = 0;
            return 0;
        }

        // game continue
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if (N[i][j] != 'X' && N[i][j] != 'O')
                {
                    return 1;
                }
            }
        }
        // check draw
        draw = 1;
        return 0;
    }
    void result() // show Player_1 && Player_2 Win. And total draw.
    {
        if (turn == 'O' && draw == 0)
        {
            cout << "Player-1 ";
            cout << Player_Name::get_player_1();
            cout << "  Wins \n";
            P1++;
        }
        else if (turn == 'X' && draw == 0)
        {
            cout << "Player-2 ";
            cout << Player_Name::get_player_1();
            cout << " Wins \n";
            P2++;
        }
        else
        {
            cout << "Game Draw!\n";
            D++;
        }
    }
    void Reset() // Reset the board for new match.
    {
        char y = '1';
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                N[i][j] = y;
                ++y;
            }
        }
    }
    void W_L_D() // At end shows total win/draws.
    {
        cout << "\nPlayer 1 ";
        cout << Player_Name::get_player_1();
        cout << " Wins = " << P1 << endl;
        cout << "\nPlayer 2 ";
        cout << Player_Name::get_player_2();
        cout << " Wins = " << P2 << endl;
        cout << "\nDraws = " << D << endl;
    }
    void writeToFile(ofstream &file_)
    {
        file_.write(reinterpret_cast<const char *>(this), sizeof(*this));
    }
    void print_Data()
    {
        cout << "Player_1: " << Player_Name::get_player_1() << endl;
        cout << "Player_2: " << Player_Name::get_player_2() << endl;
        if (Player_Name::get_st() == 'S' || Player_Name::get_st() == 's')
        {
            cout << "Single Match " << endl;
        }
        if (Player_Name::get_st() == 'T' || Player_Name::get_st() == 't')
        {
            cout << "Tournament" << endl;
            cout << "Number of Matches played: " << Player_Name::get_loop() << endl;
        }
        cout << endl;
        cout << "PLayer-1 Wins: " << P1 << endl;
        cout << "PLayer-2 wins: " << P2 << endl;
        cout << "Draw Matches: " << D << endl;
    }
    int get_loop_control()
    {
        // cout << "get_loop_control() called\n";

        return loop_control;
    }
    void operator++(int)
    {
        ++loop_control;
    }
    void F_H2()
    {
        ofstream write;
        write.open("data.txt", ios::app);
        if (get_loop() > 1)
        {
            write << "\n\tRound " << loop_control;
        }
        write << "\n\t\t"
              << "\t\t|\t\t|\n";
        write << "\t\t"
              << "\t\t|\t\t|\n";
        write << "\t\t"
              << "\t" << N[0][0] << "\t|\t" << N[0][1] << "\t|\t" << N[0][2] << "\t\n";
        write << "\t\t"
              << "\t\t|\t\t|\n";
        write << "\t\t"
              << "----------------|---------------|------------\n";
        write << "\t\t"
              << "\t\t|\t\t|\n";
        write << "\t\t"
              << "\t\t|\t\t|\n";
        write << "\t\t"
              << "\t" << N[1][0] << "\t|\t" << N[1][1] << "\t|\t" << N[1][2] << "\t\n";
        write << "\t\t"
              << "\t\t|\t\t|\n";
        write << "\t\t"
              << "\t\t|\t\t|\n";
        write << "\t\t"
              << "----------------|---------------|-------------\n";
        write << "\t\t"
              << "\t\t|\t\t|\n";
        write << "\t\t"
              << "\t\t|\t\t|\n";
        write << "\t\t"
              << "\t" << N[2][0] << "\t|\t" << N[2][1] << "\t|\t" << N[2][2] << "\t\n";
        write << "\t\t"
              << "\t\t|\t\t|\n";
        write << "\t\t"
              << "\t\t|\t\t|\n";
        if (turn == 'O' && draw == 0)
        {
            write << "Player-1 ";
            write << get_player_1();
            write << "  Wins \n";
        }
        else if (turn == 'X' && draw == 0)
        {
            write << "Player-2 ";
            write << get_player_2();
            write << " Wins \n";
        }
        else
        {
            write << "Game Draw!\n";
        }
        write.close();
    }
    void F_H3()
    {
        ofstream write;
        write.open("data.txt", ios::app);
        write << "Result:\n";
        write << "\nPlayer 1 ";
        write << " Wins = " << P1 << endl;
        write << "\nPlayer 2 ";
        write << " Wins = " << P2 << endl;
        write << "\nDraws = " << D << endl;
        write.close();
    }
    ~Game() {

    };
};
//<------------------------------------------------------------------------------------------------------------------------------------->

//<------------------------------------------------------------------------------------------------------------------------------------->
int main()
{
    ofstream Write_("Tic Tac Toe.dat", ios::binary);
    if (!Write_)
    {
        cout << "File not created";
        return 0;
    }
    Write_.seekp(0);
    Game G;
    G.Game_start();
    G.F_H1();
    int i = G.get_loop_control();
    for (; i < G.get_loop(); i++)
    {
        while (G.game_())
        {
            if (G.get_loop() > 1)
            {
                cout << "\n\tRound " << i + 1;
            }
            G.Start();
        }
        G.F_H2();
        G.Structure();
        G.result();
        G.Reset();
        G++;
    }
    G.W_L_D();
    G.F_H3();
    G.writeToFile(Write_);
    Write_.close();
    system("pause");
    system("cls");

    ifstream Read_("Tic Tac Toe.dat", ios::binary);
    Game G_read;
    Read_.seekg(0);
    Read_.read(reinterpret_cast<char *>(&G_read), sizeof(Game));
    G_read.print_Data();
    Read_.close();
}